import { Component, OnInit } from '@angular/core';
import { Merchant } from '../merchant';

import { FeedbackService } from '../feedback.service';
@Component({
  selector: 'app-merchant',
  templateUrl: './merchant.component.html',
  styleUrls: ['./merchant.component.css']
})
export class MerchantComponent implements OnInit {
  temp: Merchant  = new Merchant();
  constructor(private service: FeedbackService) { }

  ngOnInit() {
  }

  save(data) {
    alert('Merchant feedback submitted successfully');
    this.service.MerchantResponse(data.MerchantId , data.MerchantResponse).subscribe(adata => console.log(adata));
    }
}



