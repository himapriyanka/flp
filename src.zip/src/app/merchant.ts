export class Merchant {
  public  merchantId: number;
  public merchantresponse: string;
  public  feedback_id: number;
  public  customerFeedback: number;
  public  adminComment: string;
  public  merchantstatus: string;
  public  customerId: number;
  public  customerstatus: string;
}
