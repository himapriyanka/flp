export class Response {
  public  merchantId: number;
  public merchantresponse: string;
}
