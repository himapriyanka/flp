import { Component, OnInit } from '@angular/core';

import { FeedbackService } from '../feedback.service';
import { Customer } from '../customer';
import { Merchant } from '../merchant';
@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  temp: Customer  = new Customer();
  constructor(private service: FeedbackService) { }

  ngOnInit() {
  }

save(data) {
alert('Customer feedback submitted successfully');
this.service.customerFeedback(data.customerId , data.description).subscribe(adata => console.log(adata));



}
}
