import { Component, OnInit } from '@angular/core';
import { FeedbackService } from '../feedback.service';

@Component({
  selector: 'app-customerresponse',
  templateUrl: './customerresponse.component.html',
  styleUrls: ['./customerresponse.component.css']
})
export class CustomerresponseComponent implements OnInit {
  Customerresponse: Response;
  constructor(private service: FeedbackService) { }

  ngOnInit() {
    this.Customerresponse  = new Response();
  }
save(dataa) {
  this.service.MerchantFeedbackResponse(dataa.customerId ).subscribe( data => this.Customerresponse = data);
}
}
