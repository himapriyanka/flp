import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerresponseComponent } from './customerresponse.component';

describe('CustomerresponseComponent', () => {
  let component: CustomerresponseComponent;
  let fixture: ComponentFixture<CustomerresponseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerresponseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerresponseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
