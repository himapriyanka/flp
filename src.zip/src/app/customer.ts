export class Customer {
  public  customerId: number;
  public  customerFeedback: string;
}
