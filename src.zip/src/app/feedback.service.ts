import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Customer } from './customer';
import { Merchant } from './merchant';
import { Observable } from '../../node_modules/rxjs';
@Injectable({
  providedIn: 'root'
})
export class FeedbackService {
  prod: Observable<Response>;
  constructor(private http: HttpClient) {}
  customerFeedback(customerId: number, description: String) {
    return this.http.post ( 'http://localhost:9087/feedback/sendcustfeedback/' + customerId + '/' + description, '');
  }
  MerchantResponse(merchantId: number, MerchantResponse: String) {
    return this.http.post('http://localhost:9087/feedback/sendmerchantresponse/' + merchantId + '/' + MerchantResponse, '');
  }
  MerchantFeedbackResponse(merchantId: number): Observable<any> {
    return this.http.get<Response>('http://localhost:9087/feedback/Getresponse/' + merchantId);

}

}
