import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerComponent } from './customer/customer.component';
import { MerchantComponent } from './merchant/merchant.component';
import { AdminComponent } from './admin/admin.component';
import { CustomerresponseComponent } from './customerresponse/customerresponse.component';

const routes: Routes = [
  { path: '', redirectTo: '/admin', pathMatch: 'full' },
  {path: 'customer', component: CustomerComponent},
  {path: 'merchant', component: MerchantComponent},
  {path: 'customerresponse', component: CustomerresponseComponent},
  {path: '**', component: AdminComponent},

  ];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
