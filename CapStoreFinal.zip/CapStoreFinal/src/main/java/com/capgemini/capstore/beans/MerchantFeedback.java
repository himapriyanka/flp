package com.capgemini.capstore.beans;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "capg_feedback")
public class MerchantFeedback {

	@Id
	private long feedback_id;
	@Column(length = 256)
	private String merchantresponse;
	@Column(length = 256)
	private String customerFeedback;
	private String adminComment;
	private String customerstatus;
	private String merchantstatus;
	private long customerId;
	private long merchantId;
	
	
	
	
	public MerchantFeedback() {
		super();
		// TODO Auto-generated constructor stub
	}



	public MerchantFeedback(long feedback_id, String merchantresponse, String customerFeedback, String adminComment,
			String customerstatus, String merchantstatus, long customerId, long merchantId) {
		super();
		this.feedback_id = feedback_id;
		this.merchantresponse = merchantresponse;
		this.customerFeedback = customerFeedback;
		this.adminComment = adminComment;
		this.customerstatus = customerstatus;
		this.merchantstatus = merchantstatus;
		this.customerId = customerId;
		this.merchantId = merchantId;
	}





	/**
	 * @return the feedback_id
	 */
	public long getFeedback_id() {
		return feedback_id;
	}




	/**
	 * @param feedback_id the feedback_id to set
	 */
	public  void setFeedback_id(long feedback_id) {
		this.feedback_id = feedback_id;
	}




	/**
	 * @return the merchantresponse
	 */
	public  String getMerchantresponse() {
		return merchantresponse;
	}




	/**
	 * @param merchantresponse the merchantresponse to set
	 */
	public   void setMerchantresponse(String merchantresponse) {
		this.merchantresponse = merchantresponse;
	}




	/**
	 * @return the customerFeedback
	 */
	public  String getCustomerFeedback() {
		return customerFeedback;
	}




	/**
	 * @param customerFeedback the customerFeedback to set
	 */
	public   void setCustomerFeedback(String customerFeedback) {
		this.customerFeedback = customerFeedback;
	}




	/**
	 * @return the adminComment
	 */
	public String getAdminComment() {
		return adminComment;
	}




	/**
	 * @param adminComment the adminComment to set
	 */
	public  void setAdminComment(String adminComment) {
		this.adminComment = adminComment;
	}




	/**
	 * @return the customerstatus
	 */
	public  String getCustomerstatus() {
		return customerstatus;
	}




	/**
	 * @param customerstatus the customerstatus to set
	 */
	public  void setCustomerstatus(String customerstatus) {
		this.customerstatus = customerstatus;
	}




	/**
	 * @return the merchantstatus
	 */
	public   String getMerchantstatus() {
		return merchantstatus;
	}




	/**
	 * @param merchantrstatus the merchantstatus to set
	 */
	public   void setMerchantstatus(String merchantstatus) {
		this.merchantstatus = merchantstatus;
	}




	/**
	 * @return the customerId
	 */
	public   long getCustomerId() {
		return customerId;
	}




	/**
	 * @param customerId the customerId to set
	 */
	public  void setCustomerId(long customerId) {
		this.customerId = customerId;
	}




	/**
	 * @return the merchantId
	 */
	public  long getMerchantId() {
		return merchantId;
	}




	/**
	 * @param merchantId the merchantId to set
	 */
	public   void setMerchantId(long merchantId) {
		this.merchantId = merchantId;
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MerchantFeedback [feedback_id=" + feedback_id + ", merchantresponse=" + merchantresponse
				+ ", customerFeedback=" + customerFeedback + ", adminComment=" + adminComment + ", customerstatus="
				+ customerstatus + ", merchantrstatus=" + merchantstatus + ", customerId=" + customerId
				+ ", merchantId=" + merchantId + "]";
	}



	

	


	 
















	








	

}