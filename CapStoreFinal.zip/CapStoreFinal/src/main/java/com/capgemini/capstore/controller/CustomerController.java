package com.capgemini.capstore.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.MerchantFeedback;
import com.capgemini.capstore.service.CustomerService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/feedback")
public class CustomerController {
	CustomerController() {
		MerchantFeedback bean = new MerchantFeedback();
	}

	@Autowired
	private CustomerService service;

	@PostMapping(value = "/sendAlldata")
	public List<MerchantFeedback> sendFeedback(@RequestBody MerchantFeedback bean) {

		return service.sendFeedback(bean);

	}

	@GetMapping(value = "/Getall")
	public List<MerchantFeedback> viewAllFB() {
		return service.viewAllFB();
	}

	@GetMapping("/Getthedatamerchant/{merchantId}")
	public String getAllFeedbacks(@PathVariable long merchantId) {

		return service.getAllFeedbacks(merchantId);

	}

	@GetMapping("/Getthedatacustomer/{customerId}")
	public String getAllcustomerFeedbacks(@PathVariable long customerId) {

		return service.getAllcustomerFeedbacks(customerId);

	}

	@PostMapping(value = "/sendcustfeedback/{customerId}/{customerFeedback}")
	public MerchantFeedback sendcustFeedback(@PathVariable long customerId, @PathVariable String customerFeedback) {
		return service.sendcustFeedback(customerId, customerFeedback);

	}

	/*
	 * @PostMapping(value="/sendcustfeedback") public MerchantFeedback
	 * sendcustFeedback(@PathVariable long customerId,@PathVariable String
	 * customerFeedback) { return
	 * service.sendcustFeedback(customerId,customerFeedback);
	 * 
	 * }
	 */

	@PostMapping(value = "/sendmerchantresponse/{merchantId}/{merchantresponse}")
	public MerchantFeedback sendmerchantresponse(@PathVariable long merchantId, @PathVariable String merchantresponse) {
		return service.sendmerchantresponse(merchantId, merchantresponse);

	}

	@GetMapping("/Getresponse/{merchantId}")
	public MerchantFeedback getAllmerchantFeedbacks(@PathVariable long merchantId) {
		System.out.println(service.getmerchantresponse(merchantId));
		return service.getmerchantresponse(merchantId);

	}

}